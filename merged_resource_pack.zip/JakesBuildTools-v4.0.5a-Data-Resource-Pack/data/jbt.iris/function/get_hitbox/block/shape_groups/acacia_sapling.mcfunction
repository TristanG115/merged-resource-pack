data modify storage jbt.iris:data Shape set value [{min: [0.125, 0.0, 0.125], max: [0.875, 0.75, 0.875]}]
